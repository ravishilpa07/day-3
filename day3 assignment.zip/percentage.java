import java.util.*;
class percentage
{
	public static void main(String args[])
	{
		Scanner obj=new Scanner(System.in);
		System.out.println("enter the first subject marks:  ");
		int m1=obj.nextInt();
		System.out.println("enter the second subject marks :  ");
		int m2=obj.nextInt();
		System.out.println("enter the third  subject marks :  ");
		int m3=obj.nextInt();
		System.out.println("enter the fourth subject marks :  ");
		int m4=obj.nextInt();
		System.out.println("enter the fifth subject marks  :  ");	
		int m5=obj.nextInt();
		int sum=m1+m2+m3+m4+m5;
		float avg=sum/5;
		switch ((int) avg / 10) 
{
		case 10:
			System.out.println("Grade : O");
			break;
        case 9:
            System.out.println("Grade : A+");
            break;
        case 8:
        case 7:
            System.out.println("Grade : A");
            break;
        case 6:
            System.out.println("Grade : B");
            break;
        case 5:
            System.out.println("Grade : C");
            break;
        case 4:
            System.out.println("Grade : D");
            break;
       default :
    	   System.out.println("fail");
}
}
}