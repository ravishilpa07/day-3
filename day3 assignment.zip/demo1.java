import java.util.*;
public class demo1 {
	
	
		Scanner obj=new Scanner(System.in);
		public 
			String name;
		int date,month,year;
		double salary;
		void details() {
		System.out.println("enter the name of the employee : ");
		name = obj.nextLine();
		System.out.println("enter the date of birth : ");
		date=obj.nextInt();
		System.out.println("enter the month of birth");
		month=obj.nextInt();
		System.out.println("enter the year of birth : ");
		year=obj.nextInt();
		System.out.println("enter the salary : ");
		salary=obj.nextDouble();
		}
		void display()
		{
			System.out.println("employee name: "+name);
			System.out.println("employee age : "+age());
			System.out.println("employee salary "+salary);
			System.out.println("employee tax : "+tax()+"%");
		}
	    int age()
	    {
	    	int age=2020-year;
	    	return age;
	    }
	    int tax()
	    {
	    	if (salary==500000)
	    	{
	    		return 20;
	    	}
	    	else if(salary==400000)
	    		return 15;
	    	else if(salary==300000)
	    		return 10;
	    	else if(salary==200000)
	    		return 5;
	    	else
	    		return 0;
	    	
	    }
	    public static void main(String args[]) {
	    	demo1 d=new demo1();
	    	d.details();
	    	d.display();
	    	}

}
